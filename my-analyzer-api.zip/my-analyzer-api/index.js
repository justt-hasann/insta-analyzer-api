const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

app.get('/', (req, res) => {
  res.send('API is live!');
});

app.get('/api/profile/:username', (req, res) => {
  const username = req.params.username;
  res.json({
    username,
    followers: "1,234",
    bio: "Mock bio for " + username
  });
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});